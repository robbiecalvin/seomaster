# AI search visibility (AEO/GEO)
## Baseline
Select representative informational, commercial and brand prompts. Record exact prompt, platform/model where visible, date, market, citations, brand mentions, competitor mentions and factual accuracy. Repeat samples because answers vary. Do not treat mentions as verified traffic.
## Improvement strategy
Publish original, accurate, clearly structured answers with evidence, transparent authorship, dates and useful examples. Maintain consistent brand facts and relevant third-party references. Use appropriate structured data and accessible HTML. Review crawler policies against business and licensing preferences; do not assume allowing a crawler guarantees inclusion. Avoid fabricated citations or manipulative content.
## Finding record
Prompt ID, prompt, platform, observed date, cited URLs, brands, accuracy, opportunity ID, proposed action, confidence.
## Measurement
Track citation frequency and brand mention share across a fixed prompt panel, with sample counts and platform breakdown. Track attributable referrals separately where available. No guaranteed AI placement or universal ranking metric.
