# Verification checklist
Record environment, commit, date, tester and evidence for every check. Mark PASS, FAIL, BLOCKED or NOT APPLICABLE; unchecked is not passed.
- [ ] CSV IDs and references resolve; required research fields populated or limitations recorded.
- [ ] Architecture and page specs agree on page IDs, paths, indexability and locale.
- [ ] Approved routes return intended status; redirects have no loops or chains.
- [ ] Canonicals, robots directives and sitemap agree; staging remains protected.
- [ ] Rendered titles, descriptions, headings and content match approved specifications.
- [ ] Structured data validates and matches visible content.
- [ ] Internal links resolve; intended pages are discoverable.
- [ ] Mobile layout, keyboard navigation, focus and image alternatives tested.
- [ ] Performance tested; field and lab results distinguished.
- [ ] Conversion events tested without collecting unnecessary personal data.
- [ ] Build, lint and automated tests pass; existing functionality preserved.
- [ ] Content claims and citations reviewed; no thin duplicate pages.
- [ ] Monitoring baseline and rollback documented; deployment approval recorded.
## Evidence log
| Check ID | URL/test | Result | Evidence | Owner | Remediation |
|---|---|---|---|---|---|
Ranking improvements and indexing cannot be guaranteed or verified solely by prelaunch tests.
