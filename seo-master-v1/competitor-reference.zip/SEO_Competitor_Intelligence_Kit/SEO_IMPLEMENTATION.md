# Codex implementation instructions
## Execution contract
Read README and all research files. Inspect repository architecture, routing, framework, existing content, tests and deployment configuration. Do not invent project facts or metrics. If project inputs or research are missing, report blockers and do not generate speculative production pages.
## Prioritization
Score each factor 0–10: demand (validated relative demand), competition (ranking difficulty), relevance (product fit), commercial value (conversion potential), weakness (observed competitor deficiency), effort (implementation cost). Score = round(10 × [0.20D + 0.20(10-C) + 0.25R + 0.15V + 0.10W + 0.10(10-E)]). Use high ≥75, medium 50–74, low <50. Leave score blank if inputs are unknown. Record rationale and confidence; low-confidence scores require review. These are planning weights, not ranking factors.
## Implementation sequence
1. Validate identifiers and cross-file references. Resolve keyword cannibalization and canonical conflicts. Produce a change map with paths, dependencies, risks and rollback steps.
2. Implement shared metadata, canonical, sitemap, robots and structured-data mechanisms using framework conventions.
3. Implement approved pages in priority order with original content, accessible navigation, internal links and conversion paths. Preserve existing functionality and URLs unless approved redirects are specified.
4. Run build, lint, tests, rendered-page checks and crawl verification. Record results in SEO_VERIFICATION.md.
5. Prepare reviewable diff, monitoring baseline and rollback instructions. Do not deploy, publish, purchase services or change production settings without explicit authorization.
## Acceptance
No placeholders or fabricated evidence in production. No secrets in repository. Do not overwrite user content or unrelated changes. Report files changed, tests run, failures, unresolved risks and next steps.
