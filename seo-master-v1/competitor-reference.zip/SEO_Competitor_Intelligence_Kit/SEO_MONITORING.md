# SEO monitoring
## Baseline
Record launch date, market, device, measurement windows, analytics properties and consent configuration. Use own-site Search Console and analytics for actual performance; use consistent third-party providers for competitor estimates.
| Cadence | Metrics / action |
|---|---|
| Daily after release | Availability, unexpected noindex, errors, sitemap changes |
| Weekly | Clicks, impressions, CTR, priority rankings, conversions, indexing issues |
| Monthly | Organic landing pages, non-brand trends, content decay, referring domains, competitor gaps |
| Quarterly | Refresh research, reassess architecture, AI prompt panel and opportunity scores |
## Reporting
Compare equivalent periods and year-over-year where possible; annotate releases, seasonality and tracking changes. Segment by market, device, brand and page type. Record source, dates and data limitations.
## Suggested alert thresholds (adjust after baseline)
Investigate unexpected production noindex or widespread 5xx immediately. Review organic clicks falling >25% week-over-week when sample size is meaningful; confirm tracking and seasonality before attributing cause. Review sustained priority ranking or conversion declines.
## Action log
Date, metric, baseline, observed value, affected URLs, evidence, hypothesis, action, owner, due date, outcome. Never promise rankings; measure business outcomes as well as visibility.
