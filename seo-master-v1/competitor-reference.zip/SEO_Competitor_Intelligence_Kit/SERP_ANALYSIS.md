# Search results analysis
For each priority keyword capture keyword ID, exact query, country, language, device, date, provider and personalization limitations.
## Results (repeat per query)
| Organic position | URL | Page type | Intent | Distinct value | Weakness | Evidence |
|---|---|---|---|---|---|---|
## Interpretation
Record ads, AI Overviews, local packs, featured snippets, videos and other features separately from organic positions. Identify dominant and mixed intent, authority barriers, freshness and realistic differentiation. Compare SERP overlap between related queries before mapping pages. Document volatility and whether a proposed page is justified. Link conclusions to opportunity IDs. Do not assume a single snapshot represents all users.
