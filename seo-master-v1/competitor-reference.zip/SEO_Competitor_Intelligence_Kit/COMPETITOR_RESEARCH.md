# Competitor research
## Project intake
Record project name, domain, product, audience, conversion goals, countries, languages, budget, known competitors and research date. Do not proceed with market-specific conclusions until these are known.
## Method
1. Discover 10–15 candidates using seed queries, customer alternatives and search results; select 3–5 for deep review. Classify direct, indirect, organic and aspirational competitors.
2. Record domains in COMPETITOR_DATABASE.csv with stable C-001 identifiers. Capture estimated organic traffic, ranking keywords, authority and referring domains with provider, market and date. Compare only like-for-like metrics.
3. Export ranking keywords and top pages into KEYWORD_DATABASE.csv; deduplicate by normalized query, country and language. Use K-001 identifiers. Preserve raw exports separately.
4. Inspect top ten organic results for priority queries; complete SERP_ANALYSIS.md. Identify content, architecture, technical and backlink gaps using corresponding files.
5. Score opportunities, map keywords to pages, and generate architecture and page specifications before implementation.
## Findings to complete
- Executive summary: strongest competitors, defensible advantages, major threats.
- Competitor profiles: positioning, traffic drivers, top URLs, conversion journey, content formats, publishing cadence and internal linking.
- Market trends: seasonality, branded/non-branded mix, geography, emerging demand.
- Recommendations: evidence, expected benefit, uncertainty, effort and owner.
## Evidence rules
Use public pages, permitted crawls and licensed data exports. Respect access restrictions and rate limits. Never invent traffic, search volume, backlinks or rankings. Unknown values remain blank, not zero. Label estimates, observations and hypotheses separately. Record source URLs, provider, observation date and market. Competitor conversion rates and private analytics are generally unavailable.
## Completion gate
All priority recommendations reference evidence and opportunity IDs; missing data and research limitations are explicitly documented.
