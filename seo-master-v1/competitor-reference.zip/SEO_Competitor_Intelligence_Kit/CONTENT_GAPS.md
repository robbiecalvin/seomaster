# Content gap analysis
For each cluster compare ranking pages, search intent, format, depth, originality, freshness, author credibility, evidence, accessibility and conversion path. Do not equate word count with quality.
## Repeatable finding record
- Gap ID / keyword IDs / competitor URLs / observation date:
- User problem and dominant intent:
- Existing coverage and specific deficiency:
- Original value we can provide (data, tool, expertise, examples):
- Proposed format, page ID, opportunity ID:
- Sources, confidence, effort and maintenance needs:
## Strategy
Group related queries by intent and SERP overlap; prefer one strong canonical page per intent. Consider guides, comparisons, templates, tools and product pages only where useful. Avoid doorway pages, thin scaled content and unsupported claims. Assign an owner and update cadence. Validate demand and product relevance before adding pages.
