# SEO Competitor Intelligence & Implementation Kit
Reusable starter package: 16 deliverables plus this guide. No live research has been performed; CSVs intentionally contain headers only and JSON datasets are empty. JSON record contracts describe expected fields, not formal JSON Schema validators.
## Workflow
1. Complete project intake in COMPETITOR_RESEARCH.md.
2. Populate competitor and keyword databases using public evidence and licensed tools.
3. Complete SERP, content, technical, backlink and AI analyses; populate keyword gaps.
4. Score SEO_OPPORTUNITIES.csv using SEO_IMPLEMENTATION.md.
5. Map keywords to pages, populate architecture and page specifications, review scope.
6. Give the package to Codex for approved implementation, verification and monitoring.
## Data conventions
UTF-8 CSV, one header row, ISO 8601 dates, ISO country/language codes, absolute source URLs, blank unknown values. IDs: C-001 competitor, K-001 keyword, G-001 gap, B-001 backlink, O-001 opportunity, P-001 page. Use semicolon-separated IDs in CSV multi-value cells and arrays in JSON. Keyword ID identifies query + market + language; repeat it across competitor observations (unique observation by keyword, competitor, URL, device, date). Own site may use C-OWN with a corresponding competitor database entry. Gap types: missing, weak, underserved, emerging. Page map roles: primary, secondary. Keep raw exports separately; sanitize untrusted spreadsheet formula-like values before opening in spreadsheet software.
## Starter Codex prompt
Read every file in this directory. Interview me for missing project intake details. Identify available research sources and their limitations. Complete the research files with traceable evidence, then propose a prioritized architecture and page specifications. Validate all cross-file references. Do not fabricate metrics or modify production. Present the implementation plan for approval before changing code.
