# Technical SEO audit
Record domain, crawl date, user agent, crawl limits, sample size and tools. Inspect public pages only. Compare competitor observations against own-site requirements.
| Check | Method | Expected outcome |
|---|---|---|
| Crawlability | robots.txt, links, HTTP responses | Intended public pages discoverable |
| Indexability | robots directives, canonicals, sitemap | Consistent indexable canonical URLs |
| Rendering | Compare raw and rendered HTML | Essential content and links accessible |
| Status codes | Crawl URLs and redirects | No unintended errors or chains |
| Metadata | Extract titles, descriptions, headings | Distinct, descriptive, intent-aligned |
| Architecture | Crawl depth and orphan analysis | Logical navigation and internal links |
| Structured data | Schema validator and rich results test | Valid, truthful eligible markup |
| Performance | PageSpeed / CrUX where available | LCP ≤2.5s, INP ≤200ms, CLS ≤0.1 at field p75 |
| Mobile | Responsive and interaction testing | Content parity and usable controls |
| International | hreflang and canonical checks | Reciprocal valid locale mappings if needed |
| Images | Inspect formats, dimensions, alt text | Efficient loading and meaningful alternatives |
## Finding record
Finding ID, URL, competitor ID (if applicable), evidence, observed date, severity, impact, recommended fix, owner, verification method, status.
Distinguish lab measurements from field data. Competitor index coverage cannot be verified through their private Search Console. Missing field data is unknown, not a pass.
